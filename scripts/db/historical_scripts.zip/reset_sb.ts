import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  const result = await prisma.startingBalance.updateMany({
    where: { fiscalYear: '2025' },
    data: { amount: 0 }
  });

  console.log(`Reset ${result.count} starting balances to 0 for year 2025.`);
}

main().catch(console.error).finally(() => prisma.$disconnect());
