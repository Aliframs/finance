import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

const rawText = `100000	Kas
100001	Kas USD
100002	Kas Besar
100100	Bank BRI 0509 0100 3205 300
100101	Bank BCA 4972579789
100102	Bank Mandiri 1640007306519
100103	Bank BTN 0016201300012008
100104	Bank BNI 2018665951
110000	Piutang Usaha CV Karya Makmur
110001	Piutang Usaha CV Sartika
110002	Piutang Yayasan Digdaya Tunas Nusantara
110003	Piutang CV. Rizka Abadi
110004	Piutang CV. Mustika Karya
110005	Piutang CV. King Arkha Perkasa
110006	Piutang CV. Dua Pilar Bersinergi
110007	Piutang Yayasan Berkah Galuh Peduli
110008	Piutang Yayasan Cita Luhur Sejati
110009	Piutang Yayasan Mandiri Untuk Negeri
110011	Piutang CV. Arkha Putra Perkasa
111000	Piutang Pemegang Saham PT Prima Intra Tehnology
120000	Uang Muka Pembelian Barang dagangan Modular
120001	Uang Muka Pembelian Alat Alat Dapur
120002	Uang Muka Pembelian Barang dagangan Food Tray
120003	Uang Muka Pembelian AC,Exhaust Fan
120004	Uang Muka Pembelian Furniture
120005	Uang Muka Pembelian Genzet
120006	Uang Muka Pembelian Ongkos Pasang Modular
121000	Uang Muka Pembelian Karpet
130000	Pembelian Barang dagangan Modular
130001	Pembelian Alat Alat Dapur
130002	Pembelian Barang dagangan Food Tray
130003	Pembelian Barang dagangan AC,Exhaust Fan
130004	Pembelian Barang dagangan Furniture
130005	Pembelian Barang dangangan Genzet
140000	Pembelian Karpet
140001	Pembelian Listrik
140002	Pembelian Material
140003	Reimbursment / Debit Note Biaya Pelabuhan
150000	Ongkos Pasang Modular
150001	Ongkos Pasang AC dan Exhaust Fan ,jasa Instalasi Listrik
150003	Jasa Custom Clearance/Dokumen
150004	Ongkos Kirim 
150005	Biaya Langsir, Jaga Malam, ongkos bongkar
150006	Jasa Rakit Motor
150007	Ongkos Pasang Talang Air
150008	Jasa Instalasi Alat Dapur (PT Sankeindo)
150009	Biaya Perbaikan Proyek
150010	Biaya Proyek
151000	Biaya Asuransi
151001	Biaya Branding Motor Listrik
160000	Biaya Dibayar Dimuka Perjalanan Dinas
160001	Biaya Dibayar dimuka David
160002	Biaya Sewa dibayar di Muka
160003	Biaya Dibayar Dimuka PT GLORIA
160004	Biaya Dibayar Dimuka PT PRABU
160005	Biaya Dibayar Dimuka Notaris Michael Suyono
170000	Pajak dibayar dimuka PPH22
170001	PPN Masukan
180000	Pinjaman Karyawan Johan Hariyanto
180001	Pinjaman Ari Riatna Gustika
180002	Pinjaman Daffa Earin Alghazali
180003	Pinjaman Ende Suhermawan
181000	Piutang Lain Lain PIC Bojonegoro Tuban (6 Titik) Pak David
181001	Piutang Lain Lain Nur Amanah Bojonegoro
181002	Piutang Lain Lain Yayasan Cahaya Kasih
181003	Piutang Lain Lain Berkah Galuh Peduli
181004	Piutang Lain Lain Yayasan Bertabur Kasih Bojonegoro
181005	Piutang Lain Lain Yayasan Kasih Harum Bersinar Tuban
181006	Piutang Lain Lain Koperasi PSU Sumber
181007	Piutang Lain Lain Yayasan Insan Emas Madani
181008	Piutang Lain Lain Yayasan Putra Bangsa Jaya
181009	Piutang Lain Lain CV Bheryl Putra
181010	Piutang Lain Lain CV Studio TL
181011	Piutang Lain Lain Yayasan Ponpes Al-Maimunah
181012	Piutang Lain Lain Bina Bangsa Emas
181013	Piutang Lain Lain Matahari Timur Bina Bangsa
181014	Piutang Lain Lain Berkah Abadi Jaya
181099	Piutang Lain-lain
190000	Aktiva Kendaraan 
190001	Aset Tetap Inventaris Kantor
190002	Aset Tetap Furniture
191000	Akumulasi Penyusutan Kendaraan
191001	Akumulasi Penyusutan Inventaris Kantor
191002	Akumulasi Penyusutan Furniture 
210000	Hutang Dagang Modular Wuxi Purite Import & Export Co., Ltd, China
210001	Hutang Dagang Modular Xiamen LK Trading Co ., Ltd
210002	Hutang Dagang Pembelian Alat Alat Dapur (Tikno/PT.Sankeindo)
210003	Hutang Dagang Pembelian Food Tray
210004	Hutang Dagang Pembelian Barang dagangan AC,Exhaust Fan
210005	Hutang Dagang Pembelian Barang dagangan Furniture
210006	Hutang Dagang Pembelian Genzet (Anekajaya Langgeng)
210007	Hutang Dagang Ongkos Pasang Modular dan material (Ricky/Udraji/Melisa/PT Anugrah Gabung Berdikari Utama)
210008	Hutang Dagang Ongkos Pasang Modular dan material Listrik (Surya/Firman Nurwegian/Ade Tatang/Maun/PT Dwicipta Surya Abadi)
210009	Hutang Dagang PT. Gloria Mulya Jaya
210010	Hutang Dagang Pembelian Furniture dan Ongkos Pasang PT Bintang Legenda Bola
210011	Hutang Dagang Pembelian Alat Alat Listrik (PT. Pionir Elektrik Indonesia)
210012	Hutang Dagang Pembelian Material & Listrik,Ongkos Kirim (CV. Pionir Elektrik Jakarta)
210013	Hutang Forwarding PT Tera Forwarders Indonesia
210014	Hutang Ongkos Kirim PT. Megah Surya Transportasindo
210015	Hutang Ongkos Kirim PT. Dewenei Trans Indonesia
210016	Hutang Dagang Ongkos Pasang Modular dan material (Agus Budiono Kuntjoro)
210017	Hutang Dagang PT Anugrah Sentra Persada
210018	Hutang Dagang Nifra Agra Mandiri
211000	Uang Muka Penjualan
220000	PPN Keluaran
220001	Hutang Pph21 
220002	Hutang Pph23
220003	Hutang PPh Final
220004	Hutang Pembayaran PIB
220005	Hutang PPN
220006	Hutang Pph 29
230000	Hutang Pemegang Saham William Ong
240000	Biaya Yang Masih Harus Di Bayar Pak David
240001	Biaya Yang Masih Harus Di Bayar PT. Mitra Pinashika Mustika Rent
240002	Biaya Yang Masih Harus Di Bayar Air Pam
280000	Hutang Lain Lain
300000	Modal Usaha
310000	Dividen
400000	Penjualan
500001	HPP Alat Dapur
500002	HPP Genzet
500003	HPP Food Tray
500004	HPP Jasa Instalasi Alat Dapur
500005	HPP Modular Box
500006	HPP Ongkos Pasang Modular
500007	HPP Tambahan Pekerjaan Modular
500008	HPP Pondasi Yayasan
500009	HPP Furniture
500010	HPP AC dan Exhaust Fan
500011	HPP Jasa Pasang AC dan Exhaust Fan
500012	HPP Alat Listrik
500013	HPP Biaya Pelabuhan 
500014	HPP Ongkos Kirim Food Tray
500015	HPP Jasa Penarikan Kabel
500016	HPP Ongkos Kirim 
500017	HPP Material
500018	HPP Biaya Langsir, Jaga Malam, ongkos bongkar
500019	HPP Biaya Perbaikan Proyek
500020	HPP Jasa Rakit Motor
510101	Ongkos Angkut
510102	Pembelian Material
510199	Pengurusan Dokumen Kepabean
600001	Beban Gaji
600002	Beban Tunjangan Transport
600003	Beban Tunjangan Tempat Tinggal
600004	Beban Tunjangan Internet
600005	Beban Tunjangan Perjalanan Dinas
600008	Beban Tunjangan BPJS Tenaga Kerja
600009	Beban Asuransi Karyawan
600010	Beban Bensin, Parkir, Tol Kendaraan, Transportasi
600011	Beban THR
600013	Beban Telekomunikasi
600014	Beban Listrik
600015	Beban Perjalanan Dinas
600016	Beban Perlengkapan Kantor
600017	Beban Pajak
600018	Beban Materai
600019	Beban Sewa
600020	Beban Pajak PPN BM
600021	Beban DKPTKA 
600022	Beban Pengiriman Dokumen
600023	Air Pam
600025	Tenaga Profesional
600026	Outsourching
600027	Beban Tenaga Lepas (Individu)
600028	Beban Internet
600029	Beban Tunjangan Lembur
600030	Beban Iuran Pemeliharaan Lingkungan
600031	Beban Tunjangan PPh 21
600032	Beban Pajak Masa Kini
600099	Entertaiment
600100	Keperluan Dapur
610001	Beban Penyusutan Kendaraan 
610002	Beban Penyusutan Inventaris Kantor
610003	Beban Penyusutan Furniture 
710001	Pendapatan Jasa Giro
720002	Beban Adm.Bank & Buku Cek/Giro
720003	Pajak Jasa Giro
720004	Selisih Kurs
999999	Lain Lain`;

async function run() {
  const lines = rawText.split('\\n');
  let updated = 0;
  let inserted = 0;
  
  for (const line of lines) {
    if (!line.trim()) continue;
    const parts = line.split('\\t');
    if (parts.length >= 2) {
      const num = parts[0].trim();
      const name = parts[1].trim();
      
      const existing = await prisma.masterCOA.findFirst({
        where: { accountNumber: num, fiscalYear: '2025' }
      });
      
      if (existing) {
        if (existing.accountName !== name) {
          await prisma.masterCOA.update({
            where: { id: existing.id },
            data: { accountName: name }
          });
          updated++;
        }
      } else {
        await prisma.masterCOA.create({
          data: {
            accountNumber: num,
            accountName: name,
            fiscalYear: '2025'
          }
        });
        inserted++;
      }
    }
  }
  console.log(`COA Sync Complete! Updated: ${updated}, Inserted: ${inserted}`);
}
run().catch(console.error);
