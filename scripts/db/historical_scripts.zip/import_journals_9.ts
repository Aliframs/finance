import { PrismaClient } from '@prisma/client';
import fs from 'fs';
import path from 'path';

const prisma = new PrismaClient();

function parseAmount(val: string): number {
  if (!val || val.trim() === '-') return 0;
  // Remove quotes, commas, spaces
  const clean = val.replace(/"/g, '').replace(/,/g, '').replace(/ /g, '');
  const parsed = parseFloat(clean);
  return isNaN(parsed) ? 0 : parsed;
}

function parseDateStr(dateStr: string): Date {
  const parts = dateStr.trim().split(' ');
  if (parts.length === 3) {
    const day = parseInt(parts[0], 10);
    const monthStr = parts[1].toLowerCase();
    let year = parseInt(parts[2], 10);
    if (year < 100) year += 2000;
    
    const months: Record<string, number> = { 
      'jan': 0, 'feb': 1, 'mar': 2, 'apr': 3, 'mei': 4, 'may': 4, 
      'jun': 5, 'jul': 6, 'agu': 7, 'aug': 7, 'sep': 8, 'okt': 9, 'oct': 9, 
      'nov': 10, 'des': 11, 'dec': 11 
    };
    
    // Some lines might have "Desember" instead of "Des" if they used a different format
    let month = 0;
    for (const key in months) {
      if (monthStr.startsWith(key)) {
        month = months[key];
        break;
      }
    }
    
    return new Date(Date.UTC(year, month, day, 12, 0, 0)); // Midday UTC to avoid timezone shifts
  }
  return new Date();
}

function splitCsvRow(row: string): string[] {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;
  
  for (let i = 0; i < row.length; i++) {
    const char = row[i];
    if (char === '"') {
      inQuotes = !inQuotes;
    } else if (char === ',' && !inQuotes) {
      result.push(current);
      current = '';
    } else {
      current += char;
    }
  }
  result.push(current);
  return result;
}

async function main() {
  const csvPath = path.join(process.cwd(), 'Jurnal 2025.csv');
  if (!fs.existsSync(csvPath)) {
    console.error('File not found:', csvPath);
    process.exit(1);
  }

  const content = fs.readFileSync(csvPath, 'utf8');
  const lines = content.split(/\r?\n/).filter(line => line.trim() !== '' && !line.startsWith(',,,,,,,,'));

  const dataLines = lines.slice(1); // skip header
  console.log(`Processing ${dataLines.length} journals...`);
  
  console.log('Clearing existing 2025 journals...');
  await prisma.journal.deleteMany({
    where: { fiscalYear: '2025' }
  });
  
  let inserted = 0;
  let skipped = 0;

  for (const line of dataLines) {
    const cols = splitCsvRow(line);
    if (cols.length < 8) {
      console.log('Skipping malformed line:', line);
      skipped++;
      continue;
    }

    const tanggalStr = cols[0].trim();
    const noVoucher = cols[1].trim();
    const noPerkiraan = cols[2].trim();
    const accountName = cols[3].trim().replace(/^"|"$/g, '');
    const vendorName = cols[4].trim().replace(/^"|"$/g, '');
    const description = cols[5].trim().replace(/^"|"$/g, '');
    const debit = parseAmount(cols[6]);
    const credit = parseAmount(cols[7]);

    if (!noVoucher || !noPerkiraan) {
      skipped++;
      continue;
    }

    const transactionDate = parseDateStr(tanggalStr);

    try {
      let voucher = await prisma.voucher.findUnique({ where: { voucherNumber: noVoucher } });
      if (!voucher) {
        let vendor = await prisma.masterVendor.findFirst({ where: { name: vendorName || 'Unknown Vendor' }});
        if (!vendor) {
          vendor = await prisma.masterVendor.create({
            data: { name: vendorName || 'Unknown Vendor', bankName: '-', accountNumber: '-', accountName: '-' }
          });
        }
        voucher = await prisma.voucher.create({
          data: {
            voucherNumber: noVoucher,
            fiscalYear: '2025',
            nominal: debit > 0 ? debit : credit,
            vendorId: vendor.id,
            status: 'COMPLETED',
            date: transactionDate
          }
        });
      } else {
        if (voucher.status !== 'COMPLETED' || voucher.date.getTime() !== transactionDate.getTime()) {
          await prisma.voucher.update({ 
            where: { id: voucher.id }, 
            data: { status: 'COMPLETED', date: transactionDate } 
          });
        }
      }

      let coa = await prisma.masterCOA.findFirst({
        where: { accountNumber: noPerkiraan, fiscalYear: '2025' }
      });

      if (!coa) {
        let expectedBalance = 'DEBIT';
        const firstDigit = noPerkiraan.charAt(0);
        if (firstDigit === '2' || firstDigit === '3' || firstDigit === '4' || noPerkiraan.startsWith('71')) {
          expectedBalance = 'CREDIT';
        }
        coa = await prisma.masterCOA.create({
          data: {
            accountNumber: noPerkiraan,
            accountName: accountName || 'Unknown Account',
            fiscalYear: '2025',
            normalBalance: expectedBalance,
            category: 'Imported'
          }
        });
      }

      await prisma.journal.create({
        data: {
          voucherId: voucher.id,
          coaId: coa.id,
          fiscalYear: '2025',
          description: description,
          debit,
          credit,
          date: transactionDate
        }
      });
      inserted++;
    } catch (e) {
      console.error(`Error processing ${noVoucher}:`, e);
      skipped++;
    }
  }

  console.log(`\nImport Complete!`);
  console.log(`Inserted: ${inserted}`);
  console.log(`Skipped: ${skipped}`);
}

main().catch(console.error).finally(() => prisma.$disconnect());
