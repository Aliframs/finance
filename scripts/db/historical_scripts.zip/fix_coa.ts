import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  const coas = await prisma.masterCOA.findMany();
  let updated = 0;

  for (const coa of coas) {
    let expectedBalance = 'DEBIT';
    const firstDigit = coa.accountNumber.charAt(0);
    const firstTwoDigits = coa.accountNumber.substring(0, 2);

    if (firstDigit === '1') expectedBalance = 'DEBIT';
    else if (firstDigit === '2') expectedBalance = 'CREDIT';
    else if (firstDigit === '3') expectedBalance = 'CREDIT';
    else if (firstDigit === '4') expectedBalance = 'CREDIT';
    else if (firstDigit === '5') expectedBalance = 'DEBIT';
    else if (firstDigit === '6') expectedBalance = 'DEBIT';
    else if (firstDigit === '7') {
      if (firstTwoDigits === '71') expectedBalance = 'CREDIT';
      else expectedBalance = 'DEBIT';
    }

    // Special edge cases if any
    // e.g. Akumulasi Penyusutan (19xxxx) is contra-asset, should be CREDIT
    if (firstTwoDigits === '19' && coa.accountName.toLowerCase().includes('akumulasi')) {
        expectedBalance = 'CREDIT';
    }

    if (coa.normalBalance !== expectedBalance) {
      await prisma.masterCOA.update({
        where: { id: coa.id },
        data: { normalBalance: expectedBalance }
      });
      updated++;
      console.log(`Updated ${coa.accountNumber} - ${coa.accountName} to ${expectedBalance}`);
    }
  }

  console.log(`Fixed normalBalance for ${updated} COAs.`);
}

main().catch(console.error).finally(() => prisma.$disconnect());
