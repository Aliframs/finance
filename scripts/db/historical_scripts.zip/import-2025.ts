import fs from 'fs';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

function normalizeName(name: string) {
  if (!name) return "";
  return name.toLowerCase()
    .replace(/^(pt\.|cv\.|pt |cv |ltd\.|co\.|yayasan )/gi, '')
    .replace(/[.,\-]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

async function run() {
  const rawData = JSON.parse(fs.readFileSync('d:/finance-app/raw-data-2025.json', 'utf8'));
  const rows = rawData.data;
  
  let headerIdx = -1;
  for(let i=0; i<rows.length; i++) {
    if (rows[i].join('').toLowerCase().includes('no voucher')) {
      headerIdx = i;
      break;
    }
  }
  
  if (headerIdx === -1) throw new Error("Header not found");
  
  const headers = rows[headerIdx].map((h: string) => h.toString().toLowerCase().trim());
  const dateCol = headers.findIndex((h:string) => h.includes('tanggal'));
  const voucherCol = headers.findIndex((h:string) => h.includes('no voucher'));
  const coaNoCol = headers.findIndex((h:string) => h.includes('no perkiraan') || h.includes('no akun'));
  const vendorCol = headers.findIndex((h:string) => h.includes('nama vendor'));
  const descCol = headers.findIndex((h:string) => h.includes('keterangan'));
  const debitCol = headers.findIndex((h:string) => h.includes('debit'));
  const creditCol = headers.findIndex((h:string) => h.includes('kredit'));
  
  const dbVendors = await prisma.masterVendor.findMany();
  const dbCOAs = await prisma.masterCOA.findMany({ where: { fiscalYear: '2025' } });
  
  const unmatchedVendors = new Set<string>();
  const unmatchedCOAs = new Set<string>();
  
  let voucherCount = 0;
  let journalCount = 0;
  
  // Group by voucher
  const grouped = new Map<string, any[]>();
  
  for(let i = headerIdx + 1; i < rows.length; i++) {
    const row = rows[i];
    const noVoucher = row[voucherCol]?.toString().trim();
    if (!noVoucher) continue;
    
    if (!grouped.has(noVoucher)) {
      grouped.set(noVoucher, []);
    }
    grouped.get(noVoucher)!.push(row);
  }
  
  for (const [noVoucher, vRows] of grouped.entries()) {
    voucherCount++;
    
    for (const row of vRows) {
      journalCount++;
      const vendorName = row[vendorCol]?.toString().trim();
      const coaNo = row[coaNoCol]?.toString().trim();
      
      if (vendorName && vendorName !== '-') {
        const norm = normalizeName(vendorName);
        const match = dbVendors.find(v => normalizeName(v.name) === norm || v.name.toLowerCase().includes(norm));
        if (!match) unmatchedVendors.add(vendorName);
      }
      
      if (coaNo) {
         const match = dbCOAs.find(c => c.accountNumber === coaNo);
         if (!match) unmatchedCOAs.add(coaNo + " (" + row[coaNoCol+1] + ")");
      }
    }
  }
  
  console.log("=== DRY RUN SUMMARY ===");
  console.log(`Found ${voucherCount} Vouchers, ${journalCount} Journals.`);
  console.log("Unmatched Vendors:");
  Array.from(unmatchedVendors).forEach(v => console.log(" - " + v));
  console.log("Unmatched COAs:");
  Array.from(unmatchedCOAs).forEach(c => console.log(" - " + c));
}
run();
