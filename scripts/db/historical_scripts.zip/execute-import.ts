import fs from 'fs';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

function normalizeName(name: string) {
  if (!name) return "";
  return name.toLowerCase()
    .replace(/^(pt\.|cv\.|pt |cv |ltd\.|co\.|yayasan )/gi, '')
    .replace(/[.,\-()]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

const manualMapping: Record<string, string> = {
  "pt. graha persada international": "PT. Graha Persada Internasional",
  "pt. aneka jaya langgeng sentosa ( bca )": "PT. Anekajaya Langgengsentosa",
  "pt. aneka jaya langgeng sentosa ( bri )": "PT. Anekajaya Langgengsentosa",
  "pt. anekajaya langgeng sentosa ( bri )": "PT. Anekajaya Langgengsentosa",
  "pt prima mira bersama (bri)": "PT Prima Mira Bersama",
};

async function run() {
  const rawData = JSON.parse(fs.readFileSync('d:/finance-app/raw-data-2025.json', 'utf8'));
  const rows = rawData.data;
  
  let headerIdx = -1;
  for(let i=0; i<rows.length; i++) {
    if (rows[i].join('').toLowerCase().includes('no voucher')) {
      headerIdx = i;
      break;
    }
  }
  
  if (headerIdx === -1) throw new Error("Header not found");
  
  const headers = rows[headerIdx].map((h: string) => h.toString().toLowerCase().trim());
  const dateCol = headers.findIndex((h:string) => h.includes('tanggal'));
  const voucherCol = headers.findIndex((h:string) => h.includes('no voucher'));
  const coaNoCol = headers.findIndex((h:string) => h.includes('no perkiraan') || h.includes('no akun'));
  const vendorCol = headers.findIndex((h:string) => h.includes('nama vendor'));
  const descCol = headers.findIndex((h:string) => h.includes('keterangan'));
  const debitCol = headers.findIndex((h:string) => h.includes('debit'));
  const creditCol = headers.findIndex((h:string) => h.includes('kredit'));
  
  let dbVendors = await prisma.masterVendor.findMany();
  const dbCOAs = await prisma.masterCOA.findMany({ where: { fiscalYear: '2025' } });
  
  let fallbackVendor = dbVendors.find(v => v.name === "Vendor Umum");
  if (!fallbackVendor) {
      fallbackVendor = await prisma.masterVendor.create({
          data: { name: "Vendor Umum", bankName: "", accountNumber: "", accountName: "" }
      });
      dbVendors.push(fallbackVendor);
  }

  // Group by voucher
  const grouped = new Map<string, any[]>();
  for(let i = headerIdx + 1; i < rows.length; i++) {
    const row = rows[i];
    const noVoucher = row[voucherCol]?.toString().trim();
    if (!noVoucher) continue;
    
    if (!grouped.has(noVoucher)) {
      grouped.set(noVoucher, []);
    }
    grouped.get(noVoucher)!.push(row);
  }

  console.log(`Starting import of ${grouped.size} vouchers...`);
  
  // Clean up existing Journals and Vouchers for a fresh start (optional, since this is a blank DB anyway)
  await prisma.journal.deleteMany({});
  await prisma.voucher.deleteMany({});
  console.log('Cleaned old vouchers & journals.');

  let successCount = 0;

  for (const [noVoucher, vRows] of grouped.entries()) {
    // Determine Voucher properties
    let dateStr = "";
    for (const r of vRows) {
        if (r[dateCol]) {
            dateStr = r[dateCol];
            break;
        }
    }
    if (!dateStr || isNaN(Date.parse(dateStr))) dateStr = "2025-01-01T00:00:00.000Z";
    const date = new Date(dateStr);
    
    let totalDebit = 0;
    let mainVendorId = null;

    for(const row of vRows) {
        totalDebit += parseFloat(row[debitCol]) || 0;
        const rawVendorName = row[vendorCol]?.toString().trim() || "";
        
        if (!mainVendorId && rawVendorName && rawVendorName !== '-') {
            const lowerRaw = rawVendorName.toLowerCase();
            const mappedName = manualMapping[lowerRaw] || manualMapping[lowerRaw.replace(/\s+/g, ' ')];
            let match = null;
            if (mappedName) {
                match = dbVendors.find(v => v.name.toLowerCase() === mappedName.toLowerCase());
            } else {
                const norm = normalizeName(rawVendorName);
                match = dbVendors.find(v => normalizeName(v.name) === norm || v.name.toLowerCase().includes(norm));
            }
            if (!match) {
                match = await prisma.masterVendor.create({
                    data: { name: rawVendorName, bankName: "", accountNumber: "", accountName: "" }
                });
                dbVendors.push(match);
            }
            mainVendorId = match.id;
        }
    }

    const nominal = totalDebit;
    if (!mainVendorId) mainVendorId = fallbackVendor.id;

    // Create the voucher
    const voucher = await prisma.voucher.create({
        data: {
            voucherNumber: noVoucher,
            date: date,
            nominal: nominal,
            fiscalYear: '2025',
            status: 'COMPLETED',
            type: 'PENGELUARAN',
            vendorId: mainVendorId,
            bankName: "",
            accountNumber: "",
            accountName: ""
        }
    });

    // Create Journals
    for (const row of vRows) {
      const coaNo = row[coaNoCol]?.toString().trim();
      const description = row[descCol]?.toString().trim() || "";
      const debit = parseFloat(row[debitCol]) || 0;
      const credit = parseFloat(row[creditCol]) || 0;
      
      const coa = dbCOAs.find(c => c.accountNumber === coaNo);
      if (!coa) continue; 

      let jDateStr = dateStr;
      if (row[dateCol] && !isNaN(Date.parse(row[dateCol]))) {
          jDateStr = row[dateCol];
      }
      const jDate = new Date(jDateStr);

      await prisma.journal.create({
          data: {
              voucherId: voucher.id,
              coaId: coa.id,
              fiscalYear: '2025',
              description: description,
              debit: debit,
              credit: credit,
              date: jDate,
              syncStatus: 'SYNCED' 
          }
      });
    }
    successCount++;
  }
  
  console.log(`IMPORT COMPLETE! Inserted ${successCount} vouchers and their journals.`);
}

run().catch(console.error);
