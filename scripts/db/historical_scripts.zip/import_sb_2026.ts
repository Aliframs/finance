import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

const rawData = `100000	Kas	  1,133,881 
100001	Kas USD	  -   
100002	Kas Besar	  13,328,565 
100100	Bank BRI 0509 0100 3205 300	  3,846,455 
100101	Bank BCA 4972579789	  124,689,334 
100102	Bank Mandiri 1640007306519	  4,916,335 
100103	Bank BTN 0016201300012008	  1,000,000 
100104	Bank BNI 2018665951	  1,500,000 
110000	Piutang Usaha CV Karya Makmur	  8,859,940,228 
110001	Piutang Usaha CV Sartika	  1,993,486,578 
110002	Piutang Usaha CV Arkha Putra Perkasa	  2,117,475,290 
110003	Piutang Usaha CV Rizka Abadi	  4,429,970,114 
110004	Piutang Usaha CV Mustika Karya	  4,429,970,114 
110005	Piutang Usaha CV King Arkha Perkasa	  -   
110006	Piutang Usaha CV Dua Pilar Bersinergi	  -   
110007	Piutang Usaha CV Bheryl Putra	  -   
110008	Piutang Usaha CV Studio TL	  -   
110009	Piutang Usaha CV Megah Jaya Konstruksi	  -   
110010	Piutang Usaha CV Tugas Langit	  -   
110011	Piutang Usaha CV Dikara Raksa	  -   
110012	Piutang Usaha Yayasan Bumi Indonesia Raya	  -   
110013	Piutang Usaha Yayasan Digdaya Tunas Nusantara	  -   
110014	Piutang Usaha Yayasan Mandiri Untuk Negeri	  -   
110015	Piutang Usaha Yayasan Keluarga Berkah Bersama	  -   
110016	Piutang Usaha PT Agung Berlian Nusantara	  -   
111000	Piutang Pemegang Saham PT Prima Intra Tehnology	  400,000,000 
112000	Piutang Pajak Pph 21	  -   
112001	Piutang Pajak PPh 26	  -   
112002	Piutang Pajak PPh Unifikasi	  -   
120000	Uang Muka Pembelian Barang Dagangan Modular	  771,776,862 
120001	Uang Muka Pembelian Alat Alat Dapur	  1,554,069,343 
120002	Uang Muka Pembelian Barang Dagangan Food Tray	  -   
120003	Uang Muka Pembelian AC, Exhaust Fan	  -   
120004	Uang Muka Pembelian Furniture	  89,550,000 
120005	Uang Muka Pembelian Genzet	  510,000,000 
121000	Uang Muka Pembelian Karpet	  -   
121999	Uang Muka Pembelian Lainnya	  -   
130000	Pembelian Barang dagangan Modular	  14,140,017,238 
130001	Pembelian Alat-alat Dapur	  -   
130002	Pembelian Barang dagangan Food Tray	  737,837,825 
130003	Pembelian Barang dagangan AC, Exhaust Fan	  506,365,368 
130004	Pembelian Barang dagangan Furniture	  163,750,000 
130005	Pembelian Barang dangangan Genzet	  250,000,000 
140000	Pembelian Karpet	  32,635,135 
140001	Pembelian Listrik	  410,958,031 
140002	Pembelian Material	  170,866,034 
140003	Reimbursment / Debit Note Biaya Pelabuhan	  220,018,202 
150000	Ongkos Pasang Modular	  2,253,000,000 
150001	Ongkos Pasang AC, Exhaust Fan dan Jasa Instalasi Listrik	  61,828,720 
150003	Jasa Custom Clearance/Dokumen	  363,825,000 
150004	Ongkos Kirim 	  6,828,333 
150005	Biaya Langsir, Jaga Malam, Ongkos Bongkar	  120,457,500 
150006	Jasa Rakit Motor	  -   
150007	Ongkos Pasang Talang Air	  15,000,000 
150008	Jasa Instalasi Alat Dapur (PT Sankeindo)	  229,755,000 
150009	Biaya Perbaikan Proyek	  20,000,000 
150010	Biaya Proyek	  -   
151000	Biaya Asuransi	  -   
151001	Biaya Branding Motor Listrik	  -   
160000	Biaya Dibayar Dimuka Perjalanan Dinas	  2,178,800 
160001	Biaya Dibayar Dimuka David	  -   
160002	Biaya Sewa dibayar Dimuka	  20,833,338 
160003	Biaya Dibayar Dimuka PT GLORIA	  -   
160004	Biaya Dibayar Dimuka PT PRABU	  -   
160005	Biaya Dibayar Dimuka Notaris Michael Suyono	  -   
170000	Pajak Dibayar Dimuka PPH22	  926,225,520 
170001	PPN Masukan	  -   
170002	Pajak Dibayar Dimuka PPH 25	  -   
170003	PPN Di Bayar Dimuka 	  -   
180000	Pinjaman Karyawan Johan Hariyanto	  -   
180001	Pinjaman Karyawan Ari Riatna Gustika	  -   
180002	Pinjaman Karyawan Daffa Earin Alghazali	  -   
180003	Pinjaman Karyawan Ende Suhermawan	  -   
181000	Piutang Biaya Operasional	  -   
181099	Piutang Lain-lain	  2,700,000,000 
190000	Aktiva Kendaraan 	  1,267,570,979 
190001	Aset Tetap Inventaris Kantor	  80,999,500 
190002	Aset Tetap Furniture	  7,410,300 
191000	Akumulasi Penyusutan Kendaraan	  (57,169,178)
191001	Akumulasi Penyusutan Inventaris Kantor	  (8,286,438)
191002	Akumulasi Penyusutan Furniture 	  (603,617)
192000	Investasi PT Prima Bersama Sejahtera	  -   
210000	Hutang Dagang Modular Wuxi Purite Import & Export Co., Ltd, China	  (18,091,569,386)
210001	Hutang Dagang Modular Xiamen LK Trading Co., Ltd	  -   
210002	Hutang Dagang Pembelian Alat-alat Dapur (Tikno/PT.Sankeindo)	  (4,924,836,206)
210003	Hutang Dagang Pembelian Food Tray (PT Sumber Digital Media)	  -   
210004	Hutang Dagang Pembelian Barang dagangan AC, Exhaust Fan	  (54,328)
210005	Hutang Dagang Pembelian Barang dagangan Furniture	  -   
210006	Hutang Dagang Pembelian Genzet (Anekajaya Langgeng)	  (1,232,100,000)
210007	Hutang Dagang Ongkos Pasang Modular dan Material (Ricky/Udraji/Melisa/PT Anugrah Gabung Berdikari Utama)	  (241,350,000)
210008	Hutang Dagang Ongkos Pasang Modular dan Material Listrik (Surya/Firman Nurwegian/Ade Tatang/Maun/PT Dwicipta Surya Abadi)	  (234,000,000)
210009	Hutang Dagang PT. Gloria Mulya Jaya	  (308,984,423)
210010	Hutang Dagang Pembelian Furniture dan Ongkos Pasang PT Bintang Legenda Bola	  (119,928,000)
210011	Hutang Dagang Pembelian Alat Alat Listrik (PT. Pionir Elektrik Indonesia)	  (174,636,000)
210012	Hutang Dagang Pembelian Material & Listrik, Ongkos Kirim (CV. Pionir Elektrik Jakarta)	  (88,763,220)
210013	Hutang Dagang Forwarding PT Tera Forwarders Indonesia	  -   
210014	Hutang Ongkos Kirim PT. Megah Surya Transportasindo	  (26,460,000)
210015	Hutang Ongkos Kirim PT. Dewenei Trans Indonesia	  -   
210016	Hutang Dagang Ongkos Pasang Modular dan Material (Agus Budiono Kuntjoro)	  -   
210017	Hutang Dagang PT Anugrah Sentra Persada	  -   
210018	Hutang Dagang PT Nifra Agra Mandiri	  -   
210019	Hutang Dagang Modular Anhui Import & Export Co., Ltd	  -   
211000	Uang Muka Penjualan	  (2,374,296,508)
220000	PPN Keluaran	  (1,042,160,639)
220001	Hutang Pph 21 	  (15,921,412)
220002	Hutang Pph 23	  (30,919,530)
220003	Hutang PPh Final	  (6,400,000)
220004	Hutang Pembayaran PIB	  -   
220005	Hutang PPN	  -   
220006	Hutang Pph 29	  (1,786,451,290)
220007	Hutang Pajak Pph Badan	  -   
220008	Hutang Pph 26	  -   
230000	Hutang Pemegang Saham William Ong	  (10,000,000,000)
230001	Hutang Investasi	  -   
240000	Biaya Yang Masih Harus Di Bayar Pak David	  -   
240001	Biaya Yang Masih Harus Di Bayar PT. Mitra Pinashika Mustika Rent	  -   
240002	Biaya Yang Masih Harus Di Bayar Air Pam	  -   
280000	Hutang Lain Lain	  (100,000,000)
300000	Modal Usaha	  (1,000,000,000)
310000	Dividen	  -   
310099	Ikhtisar Laba Rugi	  -   
320000	Laba Di Tahan	  (8,150,123,747)
400000	Penjualan	  -   
500001	HPP Alat Dapur	  -   
500002	HPP Genzet	  -   
500003	HPP Food Tray	  -   
500004	HPP Jasa Instalasi Alat Dapur	  -   
500005	HPP Modular Box	  -   
500006	HPP Ongkos Pasang Modular	  -   
500007	HPP Tambahan Pekerjaan Modular	  -   
500008	HPP Pondasi Yayasan	  -   
500009	HPP Furniture	  -   
500010	HPP AC dan Exhaust Fan	  -   
500011	HPP Jasa Pasang AC dan Exhaust Fan	  -   
500012	HPP Alat Listrik	  -   
500013	HPP Biaya Pelabuhan 	  -   
500014	HPP Ongkos Kirim Food Tray	  -   
500015	HPP Jasa Penarikan Kabel	  -   
500016	HPP Ongkos Kirim 	  -   
500017	HPP Material	  -   
500018	HPP Biaya Langsir, Jaga Malam, Ongkos Bongkar	  -   
500019	HPP Biaya Perbaikan Proyek	  -   
500020	HPP Jasa Rakit Motor	  -   
500021	HPP Karpet	  -   
500022	HPP Ongkos Pasang Talang Air	  -   
510101	Ongkos Angkut	  -   
510102	Pembelian Material	  -   
510199	Pengurusan Dokumen Kepabean	  -   
600001	Beban Gaji	  -   
600002	Beban Tunjangan Transport	  -   
600003	Beban Tunjangan Tempat Tinggal	  -   
600004	Beban Tunjangan Internet	  -   
600005	Beban Tunjangan Perjalanan Dinas	  -   
600006	Beban Tunjangan Makan	  -   
600007	Beban Tunjangan Lembur	  -   
600008	Beban Tunjangan BPJS Tenaga Kerja	  -   
600009	Beban Asuransi Karyawan	  -   
600010	Beban Bensin, Parkir, Toll, Kendaraan, Transportasi	  -   
600011	Beban THR	  -   
600012	Beban Tunjangan Entertaiment	  -   
600013	Beban Telekomunikasi	  -   
600014	Beban Listrik	  -   
600015	Beban Perjalanan Dinas	  -   
600016	Beban Perlengkapan Kantor	  -   
600017	Beban Pajak	  -   
600018	Beban Materai	  -   
600019	Beban Sewa	  -   
600020	Beban Pajak PPN BM	  -   
600021	Beban DKPTKA 	  -   
600022	Beban Pengiriman Dokumen	  -   
600023	Beban Air Pam	  -   
600025	Beban Tenaga Profesional	  -   
600026	Beban Outsourching	  -   
600027	Beban Tenaga Lepas (Individu)	  -   
600028	Beban Internet	  -   
600029	Beban Material	  -   
600030	Beban Iuran Pemeliharaan Lingkungan	  -   
600032	Beban Pajak Masa Kini	  -   
600033	Beban Bunga	  -   
600099	Entertaiment	  -   
600100	Keperluan Dapur	  -   
610001	Beban Penyusutan Kendaraan 	  -   
610002	Beban Penyusutan Inventaris Kantor	  -   
610003	Beban Penyusutan Furniture 	  -   
710001	Pendapatan Jasa Giro	  -   
720002	Beban Adm.Bank & Buku Cek/Giro	  -   
720003	Pajak Jasa Giro	  -   
720004	Selisih Kurs	  -   
999999	Lain Lain	  -   `;

function parseAmount(val: string): number {
  let cleaned = val.trim().replace(/,/g, '');
  if (cleaned === '-') return 0;
  if (cleaned.startsWith('(') && cleaned.endsWith(')')) {
    return parseFloat(cleaned.slice(1, -1));
  }
  return parseFloat(cleaned) || 0;
}

function getExpectedBalance(noPerkiraan: string, accountName: string): string {
  let expectedBalance = 'DEBIT';
  const firstDigit = noPerkiraan.charAt(0);
  const firstTwoDigits = noPerkiraan.substring(0, 2);

  if (firstDigit === '1') expectedBalance = 'DEBIT';
  else if (firstDigit === '2') expectedBalance = 'CREDIT';
  else if (firstDigit === '3') expectedBalance = 'CREDIT';
  else if (firstDigit === '4') expectedBalance = 'CREDIT';
  else if (firstDigit === '5') expectedBalance = 'DEBIT';
  else if (firstDigit === '6') expectedBalance = 'DEBIT';
  else if (firstDigit === '7') {
    if (firstTwoDigits === '71') expectedBalance = 'CREDIT';
    else expectedBalance = 'DEBIT';
  }

  if (firstTwoDigits === '19' && accountName.toLowerCase().includes('akumulasi')) {
      expectedBalance = 'CREDIT';
  }
  
  return expectedBalance;
}

async function main() {
  const lines = rawData.split('\n').filter(line => line.trim() !== '');
  
  console.log('Clearing existing 2026 Starting Balances...');
  await prisma.startingBalance.deleteMany({
    where: { fiscalYear: '2026' }
  });

  let processed = 0;

  for (const line of lines) {
    const trimmedLine = line.trim();
    const match = trimmedLine.match(/^(\d{6})\s+(.+?)\s+([\d,().-]+)$/);
    if (!match) {
      console.log('Skipping line:', line);
      continue;
    }

    const noPerkiraan = match[1].trim();
    const accountName = match[2].trim();
    const amountStr = match[3].trim();
    const amount = parseAmount(amountStr);

    let coa = await prisma.masterCOA.findFirst({
      where: { accountNumber: noPerkiraan, fiscalYear: '2026' }
    });

    if (!coa) {
      const expectedBalance = getExpectedBalance(noPerkiraan, accountName);
      coa = await prisma.masterCOA.create({
        data: {
          accountNumber: noPerkiraan,
          accountName: accountName,
          fiscalYear: '2026',
          normalBalance: expectedBalance,
          category: 'Imported'
        }
      });
      console.log(`Created 2026 COA: ${noPerkiraan}`);
    } else {
        // Just make sure existing 2026 COAs have correct normal balance too
        const expectedBalance = getExpectedBalance(noPerkiraan, accountName);
        if (coa.normalBalance !== expectedBalance) {
            await prisma.masterCOA.update({
                where: { id: coa.id },
                data: { normalBalance: expectedBalance }
            });
        }
    }

    if (amount > 0) {
      await prisma.startingBalance.create({
        data: {
          coaId: coa.id,
          fiscalYear: '2026',
          amount: amount
        }
      });
      processed++;
    }
  }

  console.log(`Finished processing! Inserted ${processed} non-zero starting balances for 2026.`);
}

main().catch(console.error).finally(() => prisma.$disconnect());
