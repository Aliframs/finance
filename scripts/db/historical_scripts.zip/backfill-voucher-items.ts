import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  const vouchers = await prisma.voucher.findMany({
    include: {
      items: true,
      journals: true
    }
  });

  let backfilled = 0;

  for (const voucher of vouchers) {
    if (voucher.items.length === 0) {
      // Find the first descriptive journal
      let desc = "Migrasi Data (Tanpa Keterangan)";
      const descriptiveJournal = voucher.journals.find(j => j.description && j.description.trim() !== "");
      if (descriptiveJournal) {
        desc = descriptiveJournal.description!;
      }

      await prisma.voucherItem.create({
        data: {
          voucherId: voucher.id,
          description: desc,
          type: "JASA",
          unit: "Ls",
          qty: 1,
          price: voucher.nominal,
          nominal: voucher.nominal
        }
      });
      
      // Since it's a generic migration, we also need to ensure grandTotal is set properly if it was 0
      await prisma.voucher.update({
        where: { id: voucher.id },
        data: {
            grandTotal: voucher.nominal,
        }
      });
      backfilled++;
    }
  }

  console.log(`Backfilled ${backfilled} vouchers with VoucherItems!`);
}

main().catch(console.error).finally(() => prisma.$disconnect());
