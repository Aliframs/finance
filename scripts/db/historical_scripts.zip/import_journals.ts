import { PrismaClient } from '@prisma/client';
import fs from 'fs';
import path from 'path';

const prisma = new PrismaClient();

function parseAmount(val: string): number {
  if (!val || val.trim() === '-') return 0;
  // Remove quotes, commas, spaces
  const clean = val.replace(/"/g, '').replace(/,/g, '').replace(/ /g, '');
  const parsed = parseFloat(clean);
  return isNaN(parsed) ? 0 : parsed;
}

function splitCsvRow(row: string): string[] {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;
  
  for (let i = 0; i < row.length; i++) {
    const char = row[i];
    if (char === '"') {
      inQuotes = !inQuotes;
    } else if (char === ',' && !inQuotes) {
      result.push(current);
      current = '';
    } else {
      current += char;
    }
  }
  result.push(current);
  return result;
}

async function main() {
  const csvPath = path.join(process.cwd(), 'Buku_Jurnal_2025.csv');
  if (!fs.existsSync(csvPath)) {
    console.error('File not found:', csvPath);
    process.exit(1);
  }

  const content = fs.readFileSync(csvPath, 'utf8');
  const lines = content.split(/\r?\n/).filter(line => line.trim() !== '');

  // Header: Tanggal,No. Voucher,No. Akun,Nama Akun,Keterangan,Debit,Kredit
  const dataLines = lines.slice(1);

  console.log(`Processing ${dataLines.length} journals...`);
  
  // Clear existing 2025 journals to avoid duplicates
  console.log('Clearing existing 2025 journals...');
  await prisma.journal.deleteMany({
    where: { fiscalYear: '2025' }
  });

  // Also clear 2025 Vouchers created from migrations maybe? No, let's keep existing vouchers and just find/create
  
  let inserted = 0;
  let skipped = 0;

  // We need a dummy vendor for new vouchers
  let defaultVendor = await prisma.masterVendor.findFirst();
  if (!defaultVendor) {
    defaultVendor = await prisma.masterVendor.create({
      data: {
        name: 'MIGRATION VENDOR',
        bankName: '-',
        accountNumber: '-',
        accountName: '-'
      }
    });
  }

  for (const line of dataLines) {
    const cols = splitCsvRow(line);
    if (cols.length < 7) {
      console.log('Skipping malformed line:', line);
      skipped++;
      continue;
    }

    const tanggalStr = cols[0].trim();
    const noVoucher = cols[1].trim();
    const noPerkiraan = cols[2].trim();
    const accountName = cols[3].trim().replace(/^"|"$/g, '');
    const description = cols[4].trim().replace(/^"|"$/g, '');
    const debit = parseAmount(cols[5]);
    const credit = parseAmount(cols[6]);

    if (!noVoucher || !noPerkiraan) {
      skipped++;
      continue;
    }

    try {
      // Find or create Voucher
      let voucher = await prisma.voucher.findUnique({ where: { voucherNumber: noVoucher } });
      if (!voucher) {
        voucher = await prisma.voucher.create({
          data: {
            voucherNumber: noVoucher,
            fiscalYear: '2025',
            nominal: debit > 0 ? debit : credit,
            vendorId: defaultVendor.id,
            status: 'COMPLETED',
            date: new Date()
          }
        });
      } else {
        // Ensure status is COMPLETED
        if (voucher.status !== 'COMPLETED') {
          await prisma.voucher.update({ where: { id: voucher.id }, data: { status: 'COMPLETED' } });
        }
      }

      // Find or Create MasterCOA
      let coa = await prisma.masterCOA.findFirst({
        where: { accountNumber: noPerkiraan, fiscalYear: '2025' }
      });

      if (!coa) {
        coa = await prisma.masterCOA.create({
          data: {
            accountNumber: noPerkiraan,
            accountName: accountName || 'Unknown Account',
            fiscalYear: '2025',
            normalBalance: 'DEBIT',
            category: 'Imported'
          }
        });
        console.log(`Created new COA: ${noPerkiraan} - ${accountName}`);
      }

      // Insert Journal
      await prisma.journal.create({
        data: {
          voucherId: voucher.id,
          coaId: coa.id,
          fiscalYear: '2025',
          description: description,
          debit,
          credit,
          date: new Date()
        }
      });
      inserted++;
    } catch (e) {
      console.error(`Error processing ${noVoucher}:`, e);
      skipped++;
    }
  }

  console.log(`\nImport Complete!`);
  console.log(`Inserted: ${inserted}`);
  console.log(`Skipped: ${skipped}`);
}

main()
  .catch(console.error)
  .finally(async () => {
    await prisma.$disconnect();
  });
